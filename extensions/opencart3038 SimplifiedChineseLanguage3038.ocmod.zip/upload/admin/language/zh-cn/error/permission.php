<?php
// Heading
$_['heading_title']   = '权限不足！';

// Text
$_['text_permission'] = '无权限访问该页面，请联系系统管理员。';
<?php
// Heading
$_['heading_title']      = 'OpenCart';

// Text
$_['text_profile']       = '您的资料';
$_['text_store']         = '商店';
$_['text_help']          = '帮助';
$_['text_homepage']      = 'OpenCart 主页';
$_['text_support']       = '官方论坛';
$_['text_documentation'] = '文档资料';
$_['text_logout']        = '退出登录';
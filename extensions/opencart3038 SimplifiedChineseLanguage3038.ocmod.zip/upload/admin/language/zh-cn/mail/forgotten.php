<?php
// Text
$_['text_subject']  = '%s - 密码重置请求';
$_['text_greeting'] = '管理员 %s 请求重置新密码。';
$_['text_change']   = '若要重置密码，请点击如下链接:';
$_['text_ip']       = '发起该请求所用IP地址为：';
<?php
// Text
$_['text_subject'] = '%s - 推广帐号被拒绝!';
$_['text_welcome'] = '欢迎在 %s 注册!';
$_['text_denied']  = '抱歉您的请求被拒绝，详细信息可以在此联系网站管理员:';
$_['text_thanks']  = '感谢';
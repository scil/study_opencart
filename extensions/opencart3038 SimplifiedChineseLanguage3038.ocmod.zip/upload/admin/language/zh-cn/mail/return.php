<?php
// Text
$_['text_subject']       = '%s - 退货更新 %s';
$_['text_return_id']     = '退货 ID:';
$_['text_date_added']    = '退货日期:';
$_['text_return_status'] = '退货请求已更新至如下状态：';
$_['text_comment']       = '退货备注为：';
$_['text_footer']        = '如有问题可以回复本邮件。';
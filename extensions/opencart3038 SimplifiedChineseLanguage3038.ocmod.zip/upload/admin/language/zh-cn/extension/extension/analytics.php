<?php
// Heading
$_['heading_title']    = '搜索引擎分析代码';

// Text
$_['text_success']     = '成功: 已修改搜索引擎分析代码！';
$_['text_list']        = '搜索引擎分析代码列表';

// Column
$_['column_name']      = '搜索引擎分析代码名称';
$_['column_status']    = '状态';
$_['column_action']    = '操作';

// Error
$_['error_permission'] = '警告: 无权限修改搜索引擎分析代码！';

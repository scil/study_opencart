<?php
// Heading
$_['heading_title']    = '折扣券';

// Text
$_['text_extension']   = '扩展功能';
$_['text_success']     = '成功: 已修改折扣券！';
$_['text_edit']        = '编辑 折扣券';

// Entry
$_['entry_status']     = '状态';
$_['entry_sort_order'] = '排序';

// Error
$_['error_permission'] = '警告: 无权限修改折扣券！';
<?php
// Heading
$_['heading_title']    = '谷歌环聊';

// Text
$_['text_extension']   = '扩展功能';
$_['text_success']     = '成功: 以修改谷歌环聊!';
$_['text_edit']        = '编辑谷歌环聊';

// Entry
$_['entry_code']       = '谷歌环聊代码';
$_['entry_status']     = '状态';

// Help
$_['help_code']        = '访问 <a href="https://developers.google.com/+/hangouts/button" target="_blank">创建谷歌环聊标记</a> 并复制和粘贴生成的代码到这里文本框中。';

// Error
$_['error_permission'] = '警告: 无权限修改谷歌环聊模组！';
$_['error_code']       = '代码必填';
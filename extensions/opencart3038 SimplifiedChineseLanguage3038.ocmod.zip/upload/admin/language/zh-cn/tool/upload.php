<?php
// Heading
$_['heading_title']     = '上传文件';

// Text
$_['text_success']      = '成功: 已修改上传文件！';
$_['text_list']         = '上传文件列表';

// Column
$_['column_name']       = '上传文件名称';
$_['column_filename']   = '文件名';
$_['column_date_added'] = '添加日期';
$_['column_action']     = '操作';

// Entry
$_['entry_name']        = '上传文件名称';
$_['entry_filename']    = '文件名';
$_['entry_date_added'] 	= '添加日期';

// Error
$_['error_permission']  = '警告: 无权限修改上传文件！';
$_['error_upload']      = '无效上传文件！';
$_['error_file']        = '没找到上传文件！';
<?php
// Heading
$_['heading_title']    = '系统维护';

// Text
$_['text_maintenance'] = '系统维护';
$_['text_message']     = '<h1 style="text-align:center;">现在我们正在进行系统维护。 <br/>我们将很快结束本次维护，请稍后再访问本站。</h1>';
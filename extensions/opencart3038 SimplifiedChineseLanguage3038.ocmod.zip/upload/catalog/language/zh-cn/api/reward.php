<?php
// Text
$_['text_success']     = '成功: 已使用奖励积分！';

// Error
$_['error_permission'] = '警告: 无权限访问 API 接口！';
$_['error_reward']     = '警告: 请输入要使用的奖励积分数值！';
$_['error_points']     = '警告: 没有 %s 奖励积分，奖励积分不足！';
$_['error_maximum']    = '警告: 可用最大奖励积分为 %s！';
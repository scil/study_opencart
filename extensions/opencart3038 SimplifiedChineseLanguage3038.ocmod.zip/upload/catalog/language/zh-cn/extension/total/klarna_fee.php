<?php
$_['text_klarna_fee'] = 'Klarna 费用';
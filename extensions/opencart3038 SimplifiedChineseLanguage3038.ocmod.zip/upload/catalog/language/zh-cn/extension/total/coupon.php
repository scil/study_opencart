<?php
// Heading
$_['heading_title'] = '使用折扣券';

// Text
$_['text_coupon']   = '折扣券 (%s)';
$_['text_success']  = '成功: 已应用折扣券!';

// Entry
$_['entry_coupon']  = '此处输入折扣券码';

// Error
$_['error_coupon']  = '警告: 折扣券无效、过期或已超过使用次数！';
$_['error_empty']   = '警告: 请输入折扣券码！';
<?php
// Text
$_['text_success']					= '手机验证码发送成功，60秒后可以再次发送。';
$_['text_error']       				= '短信网关无法工作， 请充值您的账户或获取测试账户。';
$_['text_content']					= '您的验证码是： %s 。';

//Error
$_['error_telephone']				= '请输入正确的手机号码!';
$_['error_telephone_registered']	= '该手机号码已被注册!';
<?php
// Text
$_['text_title']  = '美国邮政服务';
$_['text_weight'] = '重量:';
$_['text_eta']    = '预计时间:';
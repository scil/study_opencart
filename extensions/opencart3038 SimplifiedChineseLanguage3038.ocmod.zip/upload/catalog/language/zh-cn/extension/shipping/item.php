<?php
// Text
$_['text_title']       = '按件计运费';
$_['text_description'] = '按件计运费率';
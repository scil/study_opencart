<?php

// Text
$_['text_cron_email_message'] = '<p>这是 Google Shopping 扩展的最新 CRON 任务运行报告</p><p>%s</p>';
$_['text_cron_email_subject'] = 'CRON 任务报告 - Google Shopping on OpenCart';
$_['text_per_day']            = '$%s / 天';

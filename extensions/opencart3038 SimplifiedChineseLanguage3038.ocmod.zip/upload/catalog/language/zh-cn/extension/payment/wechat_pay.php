<?php
// Heading
$_['heading_title']              = '微信扫码支付';

// Text
$_['text_title']                 = '微信扫码支付';
$_['text_checkout']              = '结帐';
$_['text_qrcode']                = '二维码';
$_['text_qrcode_description']    = '请使用微信扫描该二维码图片进行支付！';

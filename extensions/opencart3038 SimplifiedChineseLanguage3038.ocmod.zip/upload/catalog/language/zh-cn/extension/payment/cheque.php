<?php
// Text
$_['text_title']				= '支票';
$_['text_instruction']			= '支票信息';
$_['text_payable']				= '付款至： ';
$_['text_address']				= '寄送至： ';
$_['text_payment']				= '收到付款后配送货物。';
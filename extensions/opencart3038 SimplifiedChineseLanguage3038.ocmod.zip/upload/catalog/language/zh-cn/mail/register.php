<?php
// Text
$_['text_subject']        = '%s - 感谢注册';
$_['text_welcome']        = '欢迎在 %s 上注册！';
$_['text_login']          = '帐户已经建立，您可以通过如下链接使用注册时用的电邮和密码登录本网站:';
$_['text_approval']       = '登录前需要通过审核。一旦审核通过即可通过访问网站或如下链接登录本网站:';
$_['text_service']        = '一旦登录成功，您可以查看以往订单，打印发票，编辑帐户信息等。';
$_['text_thanks']         = '此致，敬礼,';
$_['text_new_customer']   = '新会员';
$_['text_signup']         = '新会员注册:';
$_['text_customer_group'] = '会员等级:';
$_['text_firstname']      = '名字:';
$_['text_lastname']       = '姓氏:';
$_['text_email']          = 'E-Mail:';
$_['text_telephone']      = '电话:';
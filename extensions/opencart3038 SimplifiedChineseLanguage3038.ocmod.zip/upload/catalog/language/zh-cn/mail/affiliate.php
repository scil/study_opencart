<?php
// Text
$_['text_subject']		        = '%s - 推广计划';
$_['text_welcome']		        = '感谢推广 %s ！';
$_['text_login']                = '账户已建立，请使用电邮地址和密码通过如下网址访问网站：';
$_['text_approval']		        = '您的账户正在审核中。 审核通过后您可以通过如下网址使用您的邮件地址和密码登录我们的网站：';
$_['text_services']		        = '登录后您可以生成链接代码， 以便跟踪佣金和您的账户信息。';
$_['text_thanks']		        = '谢谢,';
$_['text_new_affiliate']        = '新推广会员';
$_['text_signup']		        = '新注册一位推广会员:';
$_['text_website']        		= '网址:';
$_['text_customer_group'] 		= '会员等级:';
$_['text_firstname']      		= '名字:';
$_['text_lastname']       		= '姓氏:';
$_['text_company']		        = '公司:';
$_['text_email']		        = 'E-Mail:';
$_['text_telephone']	        = '电话:';
<?php
// Heading
$_['heading_title']      = 'OpenBay Pro';

// Text
$_['text_openbay']       = '多市場整合';
$_['text_ebay']          = 'eBay 是一個允許企業或私人賣家到網上拍賣和零售商品的數十億美元的在在線市場。賣家遍及全世界。';
$_['text_amazon']        = '除普通零售服務外，亞馬遜市場是一個允許第三方賣家提供全新和二手物品的在線固定價格在線市場。';

// Button
$_['button_register']    = '註冊';
$_['button_register_eu'] = '歐洲註冊';
$_['button_register_us'] = '美國註冊';

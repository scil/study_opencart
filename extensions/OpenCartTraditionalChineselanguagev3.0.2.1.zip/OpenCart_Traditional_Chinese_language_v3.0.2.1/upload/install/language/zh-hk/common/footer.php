<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2017-10-05 09:40:20
 * @modified         2017-10-07 11:45:05
 */

$_['text_project']       = '項目主頁';
$_['text_documentation'] = '教程文檔';
$_['text_support']       = '支持論壇';
$_['text_footer']        = '版權所有 &copy; 2014 OpenCart 保留所有版權';

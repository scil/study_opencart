<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2017-10-05 09:40:20
 * @modified         2017-10-07 11:45:05
 */

// Button
$_['button_continue'] = '繼續';
$_['button_back']     = '返回';

// Error
$_['error_exception'] = '錯誤代碼 (%s)：%s 在 %s 第 %s 行';

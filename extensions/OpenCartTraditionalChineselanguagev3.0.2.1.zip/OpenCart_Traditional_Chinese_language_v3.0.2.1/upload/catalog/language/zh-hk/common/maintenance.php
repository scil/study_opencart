<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-23 11:22:04
 * @modified         2016-11-05 17:37:18
 */

// Heading
$_['heading_title']     = '系統維護';

// Text
$_['text_maintenance']  = '系統維護';
$_['text_message']      = '<h1 style="text-align:center;">現在我們正在進行系統維護。 <br/>我們將很快結束本次維護，請稍後再訪問本站。</h1>';

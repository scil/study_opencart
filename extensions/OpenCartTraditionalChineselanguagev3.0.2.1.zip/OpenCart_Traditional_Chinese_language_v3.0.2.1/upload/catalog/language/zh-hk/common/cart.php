<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-23 11:22:04
 * @modified         2016-11-05 17:37:18
 */

// Text
$_['text_items']             = '%s 件商品 - %s';
$_['text_empty']             = '您的購物車內沒有商品！';
$_['text_cart']              = '查看購物車';
$_['text_checkout']          = '去結賬';
$_['text_recurring']         = '分期付款';

<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-23 11:22:04
 * @modified         2016-11-05 17:37:17
 */

// Heading
$_['heading_title']     = '下載檔案';

// Text
$_['text_account']      = '會員中心';
$_['text_downloads']    = '下載檔案';
$_['text_empty']        = '您沒有可下載的檔案！';

// Column
$_['column_order_id']   = '訂單號';
$_['column_name']       = '名稱';
$_['column_size']       = '大小';
$_['column_date_added'] = '添加時間';

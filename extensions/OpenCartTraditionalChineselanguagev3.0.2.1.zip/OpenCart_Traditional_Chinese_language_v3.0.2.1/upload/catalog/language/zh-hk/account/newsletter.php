<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-23 11:22:04
 * @modified         2016-11-05 17:37:17
 */

// Heading
$_['heading_title']    = '訂閱本站最新動態';

// Text
$_['text_account']     = '會員中心';
$_['text_newsletter']  = '訂閱';
$_['text_success']     = '成功：您已更新訂閱狀態！';

// Entry
$_['entry_newsletter'] = '訂閱';

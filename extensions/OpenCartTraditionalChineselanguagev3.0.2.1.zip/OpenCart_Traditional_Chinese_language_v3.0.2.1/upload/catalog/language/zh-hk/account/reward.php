<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-23 11:22:04
 * @modified         2016-11-05 17:37:17
 */

// Heading
$_['heading_title']      = '我的獎勵積分';

// Column
$_['column_date_added']  = '獲取日期';
$_['column_description'] = '說明';
$_['column_points']      = '獎勵積分數';

// Text
$_['text_account']       = '賬戶';
$_['text_reward']        = '獎勵積分';
$_['text_total']         = '我的獎勵積分總數為';
$_['text_empty']         = '您現在還沒有獲取過獎勵積分！';

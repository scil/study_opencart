<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-23 11:22:04
 * @modified         2016-11-05 17:37:18
 */

// Text
$_['text_subject']  = '你收到 %s 網站的禮品券';
$_['text_greeting'] = '恭喜您，您收到一張價值 %s 的禮品券';
$_['text_from']     = '您收到來自 %s 的禮品券！';
$_['text_message']  = '贈言';
$_['text_redeem']   = '如何使用此禮品券？當您以下網站購物時，您可以在購物車頁面輸入您的禮品券號碼 <b>%s</b> 抵扣相應金額，然後進行結賬。';
$_['text_footer']   = '若您有任何疑問，請回覆本郵件。';

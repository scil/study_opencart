<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2017-10-05 09:40:20
 * @modified         2017-10-07 11:45:05
 */

// Text
$_['text_subject']  = '%s - 推廣佣金';
$_['text_received'] = '恭喜！您收到一筆來自 %s 的推廣佣金';
$_['text_amount']   = '您收到：';
$_['text_total']    = '您的總佣金為:';

<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-23 11:22:04
 * @modified         2016-11-05 17:37:18
 */

// Text
$_['text_subject']  = '%s - 請求新密碼';
$_['text_greeting'] = '此註冊郵箱地址正在請求修改 %s 網站的密碼。';
$_['text_change']   = '如是您本人操作，請點擊以下連結修改密碼：';
$_['text_ip']       = '請求修改密碼電腦 IP 地址為：';

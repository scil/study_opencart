<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2017-10-05 09:40:20
 * @modified         2017-10-07 11:45:05
 */

// Text
$_['text_subject']      = '%s - 訂單 %s';
$_['text_received']     = '收到新訂單';
$_['text_order_id']     = '訂單號';
$_['text_date_added']   = '訂單日期';
$_['text_order_status'] = '訂單狀態';
$_['text_product']      = '商品';
$_['text_total']        = '訂單金額';
$_['text_comment']      = '訂單留言';

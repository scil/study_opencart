<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-23 11:22:04
 * @modified         2016-11-05 17:37:18
 */

// Text
$_['text_upload']    = '您的檔案已經成功上傳！';

// Error
$_['error_filename'] = '檔案名必須在 2 至 64 個字元之間！';
$_['error_filetype'] = '無效檔案類型！';
$_['error_upload']   = '請選擇上傳檔案！';

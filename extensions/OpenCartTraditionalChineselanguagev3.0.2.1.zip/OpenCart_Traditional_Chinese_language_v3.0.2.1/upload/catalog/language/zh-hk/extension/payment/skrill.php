<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2017-10-05 09:40:20
 * @modified         2017-10-07 11:45:05
 */

// Text
$_['text_title'] = '信用卡/借記卡 (Skrill)';

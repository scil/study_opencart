<?php
/**
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           TL <mengwb@opencart.cn>
 * @created          2016-11-15 10:00:00
 * @modified         2016-11-15 10:00:00
 */

// Text
$_['text_time']      = '時間';
$_['text_station']   = '地點和跟蹤進度';

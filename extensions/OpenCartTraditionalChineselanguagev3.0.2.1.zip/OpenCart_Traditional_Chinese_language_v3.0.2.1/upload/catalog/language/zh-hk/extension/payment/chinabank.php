<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2017-10-05 09:40:20
 * @modified         2017-10-07 11:45:05
 */

// Text
$_['text_title']    = '網銀在線';
$_['text_reason'] 	= '原因';
$_['text_testmode']	= '警告：目前支付方式為沙盒模式（測試）。您的帳戶將無法收款。';
$_['text_total']	= '貨運，手續費，折扣和稅費';

<?php
// Text
$_['text_title'] = '信用卡/借記卡 (2Checkout)';

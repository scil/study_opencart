<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-23 11:22:04
 * @modified         2016-11-05 17:37:18
 */

// Text
$_['text_total_shipping']   = '貨運';
$_['text_total_discount']   = '折扣';
$_['text_total_tax']        = '稅費';
$_['text_total_sub']        = '小計';
$_['text_total']            = '總計';
$_['text_smp_id']           = '銷售管理員ID：';
$_['text_buyer']            = '客戶用戶名：';

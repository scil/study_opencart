<?php
// Text
$_['text_title']        = 'Pilibaba (霹靂爸爸支付)';
$_['text_redirecting']  = 'Redirecting...';
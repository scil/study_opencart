<?php
/**
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           TL <mengwb@opencart.cn>
 * @created          2016-11-23 11:12:00
 * @modified         2016-11-23 15:11:10
 */

// Text
$_['text_title'] = '銀聯支付';

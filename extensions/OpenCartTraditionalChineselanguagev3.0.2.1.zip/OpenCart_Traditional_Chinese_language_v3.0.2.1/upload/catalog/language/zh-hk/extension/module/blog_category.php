<?php
/**
 * Blog category
 *
 * @copyright        2017 opencart.cn - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2017-05-26 15:19:46
 * @modified         2017-05-26 17:18:04
 */

// Heading
$_['heading_title']    = '博客分類';


<?php
/**
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           TL <mengwb@opencart.cn>
 * @created          2016-12-12 16:04:00
 * @modified         2016-12-12 16:39:36
 */

// Heading
$_['heading_title'] = '微信掃碼支付';

// Text
$_['text_title'] = '微信掃碼支付';

$_['text_checkout']              = '結賬';
$_['text_qrcode']                = '微信掃碼支付';
$_['text_qrcode_description']    = '請使用微信掃瞄二維碼完成您的訂單支付！';

<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-23 11:22:04
 * @modified         2016-11-05 17:37:18
 */

// Heading
$_['heading_title']  = '熱賣商品';

// Text
$_['text_tax']      = '稅前';

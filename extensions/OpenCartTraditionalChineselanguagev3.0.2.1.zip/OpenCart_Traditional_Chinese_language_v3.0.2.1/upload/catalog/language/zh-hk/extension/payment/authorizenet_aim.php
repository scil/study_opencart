<?php
// Text
$_['text_title']           = '信用卡/借記卡 (Authorize.Net)';
$_['text_credit_card']     = '卡片信息';

// Entry
$_['entry_cc_owner']       = '持卡人';
$_['entry_cc_number']      = '卡號';
$_['entry_cc_expire_date'] = '過期日期';
$_['entry_cc_cvv2']        = 'CVV2 碼';

<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2017-10-05 09:40:20
 * @modified         2017-10-07 11:45:05
 */

// Text
$_['text_title']       = '支票支付';
$_['text_instruction'] = '支票支付付款說明';
$_['text_payable']     = '受益人為：';
$_['text_address']     = '請將支票寄送至：';
$_['text_payment']     = '我們將於確認收到款項後進行發貨。';

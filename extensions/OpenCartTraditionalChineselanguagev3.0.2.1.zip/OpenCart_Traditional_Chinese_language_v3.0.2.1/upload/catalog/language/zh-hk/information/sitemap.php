<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-23 11:22:04
 * @modified         2016-11-05 17:37:18
 */

// Heading
$_['heading_title']    = '網站地圖';

// Text
$_['text_special']     = '特別優惠';
$_['text_account']     = '我的賬戶';
$_['text_edit']        = '賬戶信息';
$_['text_password']    = '修改密碼';
$_['text_address']     = '收貨地址';
$_['text_history']     = '訂單記錄';
$_['text_download']    = '下載商品';
$_['text_cart']        = '購物車';
$_['text_checkout']    = '結賬';
$_['text_search']      = '搜索';
$_['text_information'] = '信息中心';
$_['text_contact']     = '聯繫我們';

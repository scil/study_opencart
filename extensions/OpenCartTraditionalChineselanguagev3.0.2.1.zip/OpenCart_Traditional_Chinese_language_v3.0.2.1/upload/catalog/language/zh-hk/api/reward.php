<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-23 11:22:04
 * @modified         2016-11-05 17:37:17
 */

// Text
$_['text_success']     = '成功：您的積分優惠已應用！';

// Error
$_['error_permission'] = '警告：您沒有權限訪問該 API！';
$_['error_reward']     = '警告：請輸入獎勵積分使用量！';
$_['error_points']     = '警告：您沒有 %s 的積分獎勵！';
$_['error_maximum']    = '警告：您的最大可使用積分為 %s！';

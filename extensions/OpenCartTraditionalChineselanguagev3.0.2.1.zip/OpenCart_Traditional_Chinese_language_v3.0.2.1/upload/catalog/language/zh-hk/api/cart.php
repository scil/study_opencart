<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-23 11:22:04
 * @modified         2016-11-05 17:37:17
 */

// Text
$_['text_success']     = '成功：購物車商品已修改！';

// Error
$_['error_permission'] = '警告：您沒有權限訪問該API！';
$_['error_stock']      = '商品標有 *** 表示數量不足或沒有存貨！';
$_['error_minimum']    = '%s 最小起訂量是 %s！';
$_['error_store']      = '該商品已不能在本店購買！';
$_['error_required']   = '%s 必選！';

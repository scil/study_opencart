<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2017-10-05 09:40:20
 * @modified         2017-10-07 11:45:05
 */

// Text
$_['text_success']     = '成功：貨幣已修改！';

// Error
$_['error_permission'] = '警告：您沒有權限訪問該API！';
$_['error_currency']   = '錯誤：貨幣代碼無效！';

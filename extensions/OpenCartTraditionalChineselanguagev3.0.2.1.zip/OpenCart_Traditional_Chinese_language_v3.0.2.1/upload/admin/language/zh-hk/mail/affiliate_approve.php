<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2017-10-05 09:40:20
 * @modified         2017-10-07 11:45:05
 */

// Text
$_['text_subject']  = '%s - 您的推廣聯盟賬號已激活！';
$_['text_welcome']  = '感謝您在 %s 註冊賬號！';
$_['text_login']    = '您的賬號已審核通過！請使用您的用戶名和密碼通過以下連結登錄網站：';
$_['text_services'] = '登錄後，你可以生成推廣跟蹤碼，以及查看佣金信息和修改賬戶信息等。';
$_['text_thanks']   = '感謝您的使用，';

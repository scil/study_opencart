<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-22 09:12:56
 * @modified         2016-11-05 17:35:25
 */

// Text
$_['text_subject']       = '%s - 退貨更新 %s';
$_['text_return_id']     = '退貨 ID';
$_['text_date_added']    = '退貨日期';
$_['text_return_status'] = '您的退貨狀態已更新';
$_['text_comment']       = '附言：';
$_['text_footer']        = '如果您有任何問題請回覆此電子郵件。';

<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2017-10-05 09:40:20
 * @modified         2017-10-07 11:45:05
 */

// Text
$_['text_subject'] = '%s - 您的賬戶未審核通過！';
$_['text_welcome'] = '感謝您在 %s 註冊賬號！';
$_['text_denied']  = '非常抱歉，您的賬戶沒有通過審核。請通過以下方式聯繫我們瞭解詳細原因：';
$_['text_thanks']  = '感謝使用，';

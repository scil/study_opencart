<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-22 09:12:56
 * @modified         2016-11-05 17:35:21
 */

// Heading
$_['heading_title']      = 'OpenCart';

// Text
$_['text_profile']       = '賬號信息';

$_['text_store']         = '網店名稱';
$_['text_help']          = '幫助';
$_['text_homepage']      = '技術支持';
$_['text_support']       = '技術論壇';
$_['text_documentation'] = '支持文檔';
$_['text_logout']        = '退出登錄';

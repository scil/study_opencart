<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-22 09:12:56
 * @modified         2016-11-05 17:35:23
 */

// Headings
$_['heading_title']   = 'Usage';
$_['text_openbay']    = 'OpenBay Pro';
$_['text_ebay']       = 'eBay';

// Text
$_['text_usage']      = 'Your account usage';

// Errors
$_['error_ajax_load'] = 'Sorry, could not get a response. Try later.';

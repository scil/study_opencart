<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-22 09:12:56
 * @modified         2016-11-05 17:35:23
 */

// Heading
$_['heading_title']         	= 'Fulfillment by Amazon';
$_['text_openbay']				= 'OpenBay Pro';
$_['text_dashboard']			= 'Fulfillment by Amazon Dashboard';

// Text
$_['text_heading_settings'] 	= 'Settings';
$_['text_heading_account'] 		= 'Account/subscription';
$_['text_heading_fulfillments'] = 'Fulfillments';
$_['text_heading_register'] 	= 'Register here';
$_['text_heading_orders'] 		= 'Orders';

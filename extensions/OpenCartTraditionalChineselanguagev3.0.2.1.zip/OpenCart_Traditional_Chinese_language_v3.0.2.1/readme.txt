OpenCart简体中文语言包 OpenCart V3.0.x

繁體語言包 OpenCart V 3.0

下載解壓後有兩個文件夾，admin目錄下的語言翻譯是後台用的，catalog目錄下的語言翻譯是前台用的。

-------------------------------------------------------------------------------------------------------------
Name: 	Traditional Chinese Language Pack
Exension Type: 	Languages
License: 	    Free
Author: 	    www.openCart.cn
Date Added: 	2021/02/06
Version 	Compatible With v3.0
-------------------------------------------------------------------------------------------------------------

1、商店後台登入：

選擇： System -> Localisation -> Languages -> Insert

填入如下：

Language Name: 繁體中文

Code = zh-hk
Locale = zh_HK.UTF-8,zh_HK,zh-hk,hongkong
Image = hk.png
Directory = zh-hk
Filename = zh-hk
Status: Enabled (啟動)
Sort Order: 任意數字

填寫後按 Save 存檔

2、把正體中文設置為預設語言：

選擇：Sytem -> Settings -> Local

在下列項目 選擇繁體中文

Language: 繁體中文
Administration Language: 繁體中文

填寫後按 Save 存檔


==================================
opencart中文网站 www.opencart.cn
==================================

演示地址：
http://demo.opencart.cn  （免费版）
http://mall.opencart.cn   (专业版)
